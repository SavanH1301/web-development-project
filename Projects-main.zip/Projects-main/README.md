# Grow More Reading Library

                                                           #HOME PAGE

<img width="1866" height="909" alt="image" src="https://github.com/user-attachments/assets/f9841c84-f63c-49da-bbc6-b411aeece88f" />

                                                           ## Facility section 
<img width="1876" height="909" alt="image" src="https://github.com/user-attachments/assets/6ee0ba11-1b09-4a6e-8b08-0a491f6bc6d0" />
                                                          # Price sectino
 <img width="1864" height="876" alt="image" src="https://github.com/user-attachments/assets/91a8f832-745e-49f4-8faa-bf87c9641aec" />

                                                         #seat booking home page for users
  <img width="1877" height="899" alt="image" src="https://github.com/user-attachments/assets/227cea59-9767-4ecc-afd9-e3628e936f64" />
   <img width="1850" height="787" alt="image" src="https://github.com/user-attachments/assets/ad2d113d-2835-48ef-82d3-fcdb82cb1848" />

                                                      #  ADMIN  PAGE 
<img width="1840" height="826" alt="image" src="https://github.com/user-attachments/assets/f69a85bb-abf9-4cfe-8079-56fa4af5ca02" />
                                                      
                                                        #Inquirey Details
<img width="1826" height="558" alt="image" src="https://github.com/user-attachments/assets/aac40acb-4100-40dc-9fbf-02a571485329" />

                                                        ##Financial Details
<img width="1846" height="850" alt="image" src="https://github.com/user-attachments/assets/0107f98c-a818-4126-b9f2-540d8a10d412" />
<img width="1838" height="914" alt="image" src="https://github.com/user-attachments/assets/9d8e17ad-dd66-4a27-a8b7-c846057580ba" />
                                                      
                                                       ## DataBase
<img width="692" height="652" alt="image" src="https://github.com/user-attachments/assets/13b63b9b-1530-40b2-b226-6817eb7b5a51" />
<img width="815" height="287" alt="image" src="https://github.com/user-attachments/assets/6b78c352-e74f-4eca-83ea-2f77eed93d64" />


                                                        


                                                    




                                                           



